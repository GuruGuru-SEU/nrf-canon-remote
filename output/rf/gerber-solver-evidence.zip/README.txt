Actual Gerber-based openEMS solver logs and port data. 1.6 mm, JLCPCB nominal dielectric baseline. See report for assumptions. All data are simulation, not physical measurement.
