Eight actual openEMS runs for three named laminate grades. NY2140 has two conditional resin-content cases. All values are approximations at 2.4 GHz. See materials-20260928.html for limitations.
